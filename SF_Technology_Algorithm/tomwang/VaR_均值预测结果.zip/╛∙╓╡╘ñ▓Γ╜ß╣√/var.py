import pandas as pd 
import os 

os.chdir('d:/user/01389648/desktop/均值预测结果/')

#派件
df_pai_train = pd.read_csv('pai_num/train_results.csv')
df_pai_test = pd.read_csv('pai_num/test_results.csv')
zone_id = set(df_pai_train['zone_id'])
split_list = [0.7, 0.75, 0.8, 0.85, 0.9, 0.95]

df_pai_var = pd.DataFrame()
for i in split_list:
    print('split_point: ', i)
    for zone in zone_id:
        print('zone_id: ',zone)
        for day in range(0,7):
            print('weekday: ', day)
            df_error = df_pai_train.loc[(df_pai_train['zone_id'] == zone) & (df_pai_train['weekday'] == day),:]
            df_error = df_error.loc[df_error['error']<=0,:]
            num = round(len(df_error) * i)
            df_error = df_error.sort_values(['error'], ascending= False).reset_index().reset_index()
            df_error = df_error[df_error['level_0'] == num-1][['zone_id','weekday','error']]
            df_error['split_point'] = i
            df_pai_var = pd.concat([df_pai_var, df_error], axis = 0)

print(df_pai_var)

for i in split_list:
    print('split: ', i)
    df_pai_merge = df_pai_var.loc[(df_pai_var['split_point'] == i), ['zone_id', 'weekday', 'error']]
    df_pai_test = pd.merge(df_pai_test, df_pai_merge, on = ['zone_id','weekday'], how = 'left')
    df_pai_test['predict_VaR_{}'.format(i)] = df_pai_test['predict'] + (-1)*df_pai_test['error']
    df_pai_test.drop(['error'], axis = 1, inplace = True)

print(df_pai_test)
df_pai_test.to_csv('pai_num/test_results_var_pai.csv')

#收件 
df_shou_train = pd.read_csv('shou_num/train_results.csv')
df_shou_test = pd.read_csv('shou_num/test_results.csv')
zone_id = set(df_shou_train['zone_id'])
split_list = [0.7, 0.75, 0.8, 0.85, 0.9, 0.95]

df_shou_var = pd.DataFrame()
for i in split_list:
    print('split_point: ', i)
    for zone in zone_id:
        print('zone_id: ',zone)
        for day in range(0,7):
            print('weekday: ', day)
            df_error = df_shou_train.loc[(df_shou_train['zone_id'] == zone) & (df_shou_train['weekday'] == day),:]
            df_error = df_error.loc[df_error['error']<=0,:]
            num = round(len(df_error) * i)
            df_error = df_error.sort_values(['error'], ascending= False).reset_index().reset_index()
            df_error = df_error[df_error['level_0'] == num-1][['zone_id','weekday','error']]
            df_error['split_point'] = i
            df_shou_var = pd.concat([df_shou_var, df_error], axis = 0)

print(df_shou_var)

for i in split_list:
    print('split: ', i)
    df_shou_merge = df_shou_var.loc[(df_shou_var['split_point'] == i), ['zone_id', 'weekday', 'error']]
    df_shou_test = pd.merge(df_shou_test, df_shou_merge, on = ['zone_id','weekday'], how = 'left')
    df_shou_test['predict_VaR_{}'.format(i)] = df_shou_test['predict'] + (-1)*df_shou_test['error']
    df_shou_test.drop(['error'], axis = 1, inplace = True)

print(df_shou_test)
df_shou_test.to_csv('shou_num/test_results_var_shou.csv')

